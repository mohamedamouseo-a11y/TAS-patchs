import {
  importTASExcelLeads as importTASExcelLeadsUnsafe,
  type TASExcelImportInput,
} from "./tasExcelCompetitiveQueue";
import { toTASExcelImportPublicError } from "./tasExcelImportErrorBoundary";

export {
  appendExistingLeadsToTASExcelQueue,
  assertNoActiveTASExcelQueueOwnershipMutation,
  getTASExcelQueueProgress,
  listTASExcelQueues,
  processTASExcelQueueFeedback,
  updateTASExcelQueueMember,
} from "./tasExcelCompetitiveQueue";

export async function importTASExcelLeads(input: TASExcelImportInput) {
  try {
    return await importTASExcelLeadsUnsafe(input);
  } catch (error) {
    // Keep the full technical error server-side, but never expose SQL/query params
    // to the browser. Do not log lead rows or imported customer data here.
    console.error("[TAS Excel Import] Import failed", {
      actorUserId: input.actorUserId,
      actorRole: input.actorRole,
      assignmentMode: input.assignmentMode,
      selectedAgentCount: input.selectedAgentIds.length,
      rowCount: input.leads.length,
      sourceFileName: input.sourceFileName ?? null,
      error,
    });
    throw toTASExcelImportPublicError(error);
  }
}
