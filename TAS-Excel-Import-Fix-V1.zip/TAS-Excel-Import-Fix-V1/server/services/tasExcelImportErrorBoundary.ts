import { TRPCError } from "@trpc/server";

const SAFE_IMPORT_ERROR_PATTERNS = [
  /^Sales Manager, Admin, or Lead Dispatcher access required$/i,
  /^Valid actorUserId is required$/i,
  /^Invalid Excel assignment mode$/i,
  /^Selected SalesAgent IDs must be unique valid positive integers$/i,
  /^No-assignment mode cannot include SalesAgents$/i,
  /^Direct assignment requires exactly one SalesAgent$/i,
  /^Competitive queue requires at least two SalesAgents$/i,
  /^At least one lead row is required$/i,
  /^Excel import is limited to 5000 rows per batch$/i,
  /^Invalid or inactive SalesAgent IDs:/i,
  /^Out-of-scope SalesAgent IDs:/i,
];

export const TAS_EXCEL_IMPORT_GENERIC_ERROR_AR =
  "تعذر بدء استيراد ملف Excel بسبب مشكلة في إعداد قاعدة البيانات. تم تسجيل التفاصيل للمراجعة.";

function isSafeImportMessage(message: string) {
  return SAFE_IMPORT_ERROR_PATTERNS.some((pattern) => pattern.test(message));
}

export function toTASExcelImportPublicError(error: unknown): TRPCError {
  if (error instanceof TRPCError) return error;

  const message = error instanceof Error ? error.message.trim() : "";
  if (message && isSafeImportMessage(message)) {
    return new TRPCError({ code: "BAD_REQUEST", message });
  }

  return new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    message: TAS_EXCEL_IMPORT_GENERIC_ERROR_AR,
  });
}
