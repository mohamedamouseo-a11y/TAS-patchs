import { describe, expect, it } from "vitest";
import { TRPCError } from "@trpc/server";
import {
  TAS_EXCEL_IMPORT_GENERIC_ERROR_AR,
  toTASExcelImportPublicError,
} from "./tasExcelImportErrorBoundary";

describe("TAS Excel import error boundary", () => {
  it("never exposes raw SQL/query parameters to the client", () => {
    const raw = new Error(
      "Failed query: INSERT INTO tas_excel_import_batches (...) VALUES (...) params: System.xlsx,competitive,[8,9],32,4,Ramadan,Admin",
    );
    const error = toTASExcelImportPublicError(raw);

    expect(error).toBeInstanceOf(TRPCError);
    expect(error.code).toBe("INTERNAL_SERVER_ERROR");
    expect(error.message).toBe(TAS_EXCEL_IMPORT_GENERIC_ERROR_AR);
    expect(error.message).not.toContain("Failed query");
    expect(error.message).not.toContain("INSERT INTO");
    expect(error.message).not.toContain("params:");
  });

  it("preserves safe validation errors", () => {
    const error = toTASExcelImportPublicError(
      new Error("Competitive queue requires at least two SalesAgents"),
    );

    expect(error.code).toBe("BAD_REQUEST");
    expect(error.message).toBe("Competitive queue requires at least two SalesAgents");
  });
});
