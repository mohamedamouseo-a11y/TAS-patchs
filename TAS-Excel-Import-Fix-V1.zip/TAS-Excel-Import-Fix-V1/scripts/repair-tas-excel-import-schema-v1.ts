import "dotenv/config";
import mysql, { type Connection, type RowDataPacket } from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL?.trim() ?? "";
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const LOCK_NAME = "tas_excel_import_schema_repair_v1";

type ColumnRepair = {
  name: string;
  ddl: string;
};

type TableSpec = {
  name: string;
  createSql: string;
  repairColumns: ColumnRepair[];
};

const tableSpecs: TableSpec[] = [
  {
    name: "tas_excel_import_batches",
    createSql: `
      CREATE TABLE IF NOT EXISTS tas_excel_import_batches (
        id INT NOT NULL AUTO_INCREMENT,
        sourceFileName VARCHAR(255) NULL,
        assignmentMode ENUM('none','direct','competitive') NOT NULL,
        selectedAgentIds JSON NULL,
        totalRows INT NOT NULL DEFAULT 0,
        importedRows INT NOT NULL DEFAULT 0,
        failedRows INT NOT NULL DEFAULT 0,
        duplicateRows INT NOT NULL DEFAULT 0,
        failureSummary JSON NULL,
        status ENUM('processing','completed','failed','cancelled') NOT NULL DEFAULT 'processing',
        createdByUserId INT NOT NULL,
        createdByUserName VARCHAR(255) NULL,
        createdByUserRole VARCHAR(64) NOT NULL,
        completedAt TIMESTAMP NULL,
        createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_tas_excel_batches_created_by (createdByUserId),
        KEY idx_tas_excel_batches_status_created (status, createdAt)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `,
    // Missing columns are added in a forward-compatible form. Nullable variants are
    // intentional for actor/mode fields so pre-existing legacy rows are never destroyed
    // or force-backfilled. New application inserts still provide all required values.
    repairColumns: [
      { name: "sourceFileName", ddl: "VARCHAR(255) NULL" },
      { name: "assignmentMode", ddl: "ENUM('none','direct','competitive') NULL DEFAULT 'none'" },
      { name: "selectedAgentIds", ddl: "JSON NULL" },
      { name: "totalRows", ddl: "INT NOT NULL DEFAULT 0" },
      { name: "importedRows", ddl: "INT NOT NULL DEFAULT 0" },
      { name: "failedRows", ddl: "INT NOT NULL DEFAULT 0" },
      { name: "duplicateRows", ddl: "INT NOT NULL DEFAULT 0" },
      { name: "failureSummary", ddl: "JSON NULL" },
      { name: "status", ddl: "ENUM('processing','completed','failed','cancelled') NULL DEFAULT 'processing'" },
      { name: "createdByUserId", ddl: "INT NULL" },
      { name: "createdByUserName", ddl: "VARCHAR(255) NULL" },
      { name: "createdByUserRole", ddl: "VARCHAR(64) NULL" },
      { name: "completedAt", ddl: "TIMESTAMP NULL" },
      { name: "createdAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP" },
      { name: "updatedAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" },
    ],
  },
  {
    name: "tas_lead_queues",
    createSql: `
      CREATE TABLE IF NOT EXISTS tas_lead_queues (
        id INT NOT NULL AUTO_INCREMENT,
        importBatchId INT NOT NULL,
        status ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
        createdByUserId INT NOT NULL,
        createdByUserRole VARCHAR(64) NOT NULL,
        completedAt TIMESTAMP NULL,
        cancelledAt TIMESTAMP NULL,
        createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY ux_tas_lead_queues_import_batch (importBatchId),
        KEY idx_tas_lead_queues_status_created (status, createdAt),
        CONSTRAINT fk_tas_lead_queues_batch
          FOREIGN KEY (importBatchId) REFERENCES tas_excel_import_batches(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_lead_queues_created_by
          FOREIGN KEY (createdByUserId) REFERENCES users(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `,
    repairColumns: [
      { name: "importBatchId", ddl: "INT NULL" },
      { name: "status", ddl: "ENUM('active','completed','cancelled') NULL DEFAULT 'active'" },
      { name: "createdByUserId", ddl: "INT NULL" },
      { name: "createdByUserRole", ddl: "VARCHAR(64) NULL" },
      { name: "completedAt", ddl: "TIMESTAMP NULL" },
      { name: "cancelledAt", ddl: "TIMESTAMP NULL" },
      { name: "createdAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP" },
      { name: "updatedAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" },
    ],
  },
  {
    name: "tas_lead_queue_members",
    createSql: `
      CREATE TABLE IF NOT EXISTS tas_lead_queue_members (
        id INT NOT NULL AUTO_INCREMENT,
        queueId INT NOT NULL,
        userId INT NOT NULL,
        memberOrder INT NOT NULL,
        status ENUM('active','paused','removed') NOT NULL DEFAULT 'active',
        currentEntryId INT NULL,
        readyAt TIMESTAMP NULL,
        assignedCount INT NOT NULL DEFAULT 0,
        feedbackCount INT NOT NULL DEFAULT 0,
        addedByUserId INT NOT NULL,
        pausedAt TIMESTAMP NULL,
        removedAt TIMESTAMP NULL,
        createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY ux_tas_queue_members_queue_user (queueId, userId),
        UNIQUE KEY ux_tas_queue_members_queue_order (queueId, memberOrder),
        UNIQUE KEY ux_tas_queue_members_current_entry (currentEntryId),
        KEY idx_tas_queue_members_ready (queueId, status, readyAt, memberOrder),
        KEY idx_tas_queue_members_user (userId, status),
        CONSTRAINT fk_tas_queue_members_queue
          FOREIGN KEY (queueId) REFERENCES tas_lead_queues(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_members_user
          FOREIGN KEY (userId) REFERENCES users(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_members_added_by
          FOREIGN KEY (addedByUserId) REFERENCES users(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `,
    repairColumns: [
      { name: "queueId", ddl: "INT NULL" },
      { name: "userId", ddl: "INT NULL" },
      { name: "memberOrder", ddl: "INT NULL" },
      { name: "status", ddl: "ENUM('active','paused','removed') NULL DEFAULT 'active'" },
      { name: "currentEntryId", ddl: "INT NULL" },
      { name: "readyAt", ddl: "TIMESTAMP NULL" },
      { name: "assignedCount", ddl: "INT NOT NULL DEFAULT 0" },
      { name: "feedbackCount", ddl: "INT NOT NULL DEFAULT 0" },
      { name: "addedByUserId", ddl: "INT NULL" },
      { name: "pausedAt", ddl: "TIMESTAMP NULL" },
      { name: "removedAt", ddl: "TIMESTAMP NULL" },
      { name: "createdAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP" },
      { name: "updatedAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" },
    ],
  },
  {
    name: "tas_lead_queue_entries",
    createSql: `
      CREATE TABLE IF NOT EXISTS tas_lead_queue_entries (
        id INT NOT NULL AUTO_INCREMENT,
        queueId INT NOT NULL,
        importBatchId INT NOT NULL,
        leadId INT NOT NULL,
        sequenceNo INT NOT NULL,
        status ENUM('waiting','assigned','completed','cancelled') NOT NULL DEFAULT 'waiting',
        assignedMemberId INT NULL,
        assignedToUserId INT NULL,
        assignmentReason VARCHAR(128) NULL,
        queuedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        assignedAt TIMESTAMP NULL,
        feedbackActivityId INT NULL,
        feedbackType VARCHAR(64) NULL,
        feedbackAt TIMESTAMP NULL,
        completedAt TIMESTAMP NULL,
        cancelledAt TIMESTAMP NULL,
        createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY ux_tas_queue_entries_lead (leadId),
        UNIQUE KEY ux_tas_queue_entries_queue_sequence (queueId, sequenceNo),
        UNIQUE KEY ux_tas_queue_entries_feedback_activity (feedbackActivityId),
        KEY idx_tas_queue_entries_next (queueId, status, sequenceNo, id),
        KEY idx_tas_queue_entries_active_agent (queueId, assignedToUserId, status),
        KEY idx_tas_queue_entries_lead_status (leadId, status),
        CONSTRAINT fk_tas_queue_entries_queue
          FOREIGN KEY (queueId) REFERENCES tas_lead_queues(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_entries_batch
          FOREIGN KEY (importBatchId) REFERENCES tas_excel_import_batches(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_entries_member
          FOREIGN KEY (assignedMemberId) REFERENCES tas_lead_queue_members(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_entries_lead
          FOREIGN KEY (leadId) REFERENCES leads(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_entries_assigned_user
          FOREIGN KEY (assignedToUserId) REFERENCES users(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT,
        CONSTRAINT fk_tas_queue_entries_feedback_activity
          FOREIGN KEY (feedbackActivityId) REFERENCES activities(id)
          ON UPDATE RESTRICT ON DELETE RESTRICT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `,
    repairColumns: [
      { name: "queueId", ddl: "INT NULL" },
      { name: "importBatchId", ddl: "INT NULL" },
      { name: "leadId", ddl: "INT NULL" },
      { name: "sequenceNo", ddl: "INT NULL" },
      { name: "status", ddl: "ENUM('waiting','assigned','completed','cancelled') NULL DEFAULT 'waiting'" },
      { name: "assignedMemberId", ddl: "INT NULL" },
      { name: "assignedToUserId", ddl: "INT NULL" },
      { name: "assignmentReason", ddl: "VARCHAR(128) NULL" },
      { name: "queuedAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP" },
      { name: "assignedAt", ddl: "TIMESTAMP NULL" },
      { name: "feedbackActivityId", ddl: "INT NULL" },
      { name: "feedbackType", ddl: "VARCHAR(64) NULL" },
      { name: "feedbackAt", ddl: "TIMESTAMP NULL" },
      { name: "completedAt", ddl: "TIMESTAMP NULL" },
      { name: "cancelledAt", ddl: "TIMESTAMP NULL" },
      { name: "createdAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP" },
      { name: "updatedAt", ddl: "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" },
    ],
  },
];

async function getDatabaseName(connection: Connection) {
  const [rows] = await connection.query<RowDataPacket[]>("SELECT DATABASE() AS database_name");
  const name = String(rows[0]?.database_name ?? "").trim();
  if (!name) throw new Error("Unable to determine active database name");
  return name;
}

async function getColumns(connection: Connection, tableName: string) {
  const [rows] = await connection.execute<RowDataPacket[]>(
    `SELECT COLUMN_NAME AS column_name
       FROM information_schema.columns
      WHERE table_schema = DATABASE() AND table_name = ?`,
    [tableName],
  );
  return new Set(rows.map((row) => String(row.column_name)));
}

async function ensureTable(connection: Connection, spec: TableSpec) {
  await connection.query(spec.createSql);
  let columns = await getColumns(connection, spec.name);
  if (!columns.has("id")) {
    throw new Error(`${spec.name} exists but has no id column; refusing automatic repair`);
  }

  const repaired: string[] = [];
  for (const column of spec.repairColumns) {
    if (columns.has(column.name)) continue;
    await connection.query(
      `ALTER TABLE \`${spec.name}\` ADD COLUMN \`${column.name}\` ${column.ddl}`,
    );
    repaired.push(column.name);
    columns = await getColumns(connection, spec.name);
  }

  const stillMissing = spec.repairColumns
    .map((column) => column.name)
    .filter((name) => !columns.has(name));
  if (stillMissing.length) {
    throw new Error(`${spec.name} is still missing columns: ${stillMissing.join(", ")}`);
  }

  return repaired;
}

async function verifyFailingInsertShape(connection: Connection) {
  const [users] = await connection.query<RowDataPacket[]>(`
    SELECT id, name, role
      FROM users
     WHERE deletedAt IS NULL
       AND COALESCE(isActive, 1) = 1
     ORDER BY id ASC
     LIMIT 1
  `);
  const actor = users[0];
  if (!actor?.id) {
    throw new Error("Cannot verify TAS Excel import insert: no active user was found");
  }

  await connection.beginTransaction();
  try {
    const [batchResult] = await connection.execute<any>(`
      INSERT INTO tas_excel_import_batches (
        sourceFileName, assignmentMode, selectedAgentIds, totalRows,
        importedRows, failedRows, duplicateRows, status,
        createdByUserId, createdByUserName, createdByUserRole
      ) VALUES (?, ?, ?, ?, 0, 0, 0, 'processing', ?, ?, ?)
    `, [
      "__tas_excel_import_schema_smoke_test__.xlsx",
      "none",
      JSON.stringify([]),
      0,
      Number(actor.id),
      actor.name ?? "Schema Repair",
      actor.role ?? "Admin",
    ]);

    const batchId = Number(batchResult?.insertId ?? 0);
    if (!batchId) throw new Error("Smoke test did not create an import batch id");

    const [queueResult] = await connection.execute<any>(`
      INSERT INTO tas_lead_queues (
        importBatchId, status, createdByUserId, createdByUserRole
      ) VALUES (?, 'active', ?, ?)
    `, [batchId, Number(actor.id), actor.role ?? "Admin"]);
    if (!Number(queueResult?.insertId ?? 0)) {
      throw new Error("Smoke test did not create a queue id");
    }

    await connection.rollback();
  } catch (error) {
    await connection.rollback().catch(() => undefined);
    throw error;
  }
}

async function main() {
  const connection = await mysql.createConnection(databaseUrl);
  let lockAcquired = false;
  try {
    const databaseName = await getDatabaseName(connection);
    const expectedDatabaseName = process.env.TAS_EXPECTED_DATABASE_NAME?.trim();
    if (expectedDatabaseName && expectedDatabaseName !== databaseName) {
      throw new Error(
        `Refusing TAS Excel schema repair on database ${databaseName}; expected ${expectedDatabaseName}`,
      );
    }

    const [lockRows] = await connection.execute<RowDataPacket[]>(
      "SELECT GET_LOCK(?, 30) AS acquired",
      [LOCK_NAME],
    );
    lockAcquired = Number(lockRows[0]?.acquired ?? 0) === 1;
    if (!lockAcquired) throw new Error("Could not acquire TAS Excel schema repair lock");

    const repairs: Record<string, string[]> = {};
    for (const spec of tableSpecs) {
      repairs[spec.name] = await ensureTable(connection, spec);
    }

    await verifyFailingInsertShape(connection);

    const changed = Object.values(repairs).reduce((sum, columns) => sum + columns.length, 0);
    console.log(`TAS_EXCEL_IMPORT_SCHEMA_REPAIR=PASS database=${databaseName} columns_added=${changed}`);
    for (const [table, columns] of Object.entries(repairs)) {
      console.log(`${table}: ${columns.length ? `added ${columns.join(", ")}` : "already compatible"}`);
    }
    console.log("Smoke test: batch insert + competitive queue insert passed and rolled back.");
  } finally {
    if (lockAcquired) {
      await connection.execute("SELECT RELEASE_LOCK(?)", [LOCK_NAME]).catch(() => undefined);
    }
    await connection.end();
  }
}

main().catch((error) => {
  console.error("TAS_EXCEL_IMPORT_SCHEMA_REPAIR=FAIL", error);
  process.exit(1);
});
