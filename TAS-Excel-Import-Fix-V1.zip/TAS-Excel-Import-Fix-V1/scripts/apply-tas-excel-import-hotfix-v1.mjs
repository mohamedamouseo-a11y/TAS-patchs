import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const routersPath = path.join(root, "server/routers.ts");
const oldImport = '} from "./services/tasExcelCompetitiveQueue";';
const newImport = '} from "./services/tasExcelCompetitiveQueueSafe";';

if (!fs.existsSync(routersPath)) {
  throw new Error(`Cannot find ${routersPath}. Run this script from the TAS repository root.`);
}

const source = fs.readFileSync(routersPath, "utf8");
if (source.includes(newImport)) {
  console.log("TAS_EXCEL_IMPORT_HOTFIX=ALREADY_APPLIED");
  process.exit(0);
}

const matches = source.split(oldImport).length - 1;
if (matches !== 1) {
  throw new Error(
    `Expected exactly one TAS Excel competitive queue import in server/routers.ts, found ${matches}. No file was changed.`,
  );
}

const updated = source.replace(oldImport, newImport);
const tempPath = `${routersPath}.tas-excel-hotfix-${process.pid}.tmp`;
fs.writeFileSync(tempPath, updated, { encoding: "utf8", mode: 0o644 });
fs.renameSync(tempPath, routersPath);

console.log("TAS_EXCEL_IMPORT_HOTFIX=APPLIED");
console.log("Changed server/routers.ts to use the sanitized TAS Excel import boundary.");
